from tkinter import *
from tkinter import messagebox
from csv import writer


window = Tk()
window.geometry('570x600+300+65')
window.title("Word's Quest")
window.configure(background='black')
window.resizable(False, False)

img1 = PhotoImage(file="new.jpg")

img0 = Label(window, image=img1, bg='black', )
img0.place(x=190, y=5)


def add():
    word = ent.get(0.0, END).lower()
    meaning = placeholder.get(0.0, END).lower()
    with open('dictionary.csv', 'a', newline="") as f:
        write = writer(f)
        write.writerow([word, meaning])
        placeholder.delete(0.0, END)
        ent.delete(0.0, END)
        messagebox.showinfo("Info", "Word added successfully")


def clear():
    ent.delete(0.0, END)
    placeholder.delete(0.0, END)


def back():
    window.destroy()
    from eni import app
    app()


my_frame = Frame(window, width=45, height='10', background='white')
my_frame.place(x=0, y=310)
ver_scroll = Scrollbar(my_frame)
ver_scroll.pack(side=RIGHT, fill=Y)
hor_scroll = Scrollbar(my_frame, orient='horizontal')
hor_scroll.pack(side=BOTTOM, fill=X)
lab = Label(window, text='Word: ', font=('Arial', 16), background='black', foreground='white')
lab.place(x=0, y=225)
lab = Label(window, text='Meaning: ', font=('Arial', 16), background='black', foreground='white')
lab.place(x=0, y=280)
sub = Button(window, text='Add word', font=('Arial', 9), borderwidth=10, command=add, padx=2)
sub.place(x=296, y=555)
ent = Text(window, font=("", 18), width=20, height=1, borderwidth=8,  fg="black", bg="white")
ent.place(x=70, y=220)
placeholder = Text(my_frame, yscrollcommand=ver_scroll.set, wrap='none', xscrollcommand=hor_scroll.set,
                   font=('Arial', 16), width=45, borderwidth=6, height='9', )
placeholder.pack()
back = Button(window, text='X', background='black', foreground='white', font=('Arial', 10), command=back, padx=2)
back.place(x=0, y=0)
remove = Button(window, text='Clear', font=('Arial', 10), command=clear, borderwidth=10,  padx=2)
remove.place(x=180, y=555)

ver_scroll.config(command=placeholder.yview)
hor_scroll.config(command=placeholder.xview)

window.mainloop()

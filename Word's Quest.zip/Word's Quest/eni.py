from tkinter import *
from tkinter import messagebox
import csv


app = Tk()
app.geometry('570x600+300+65')
app.title("Word's Quest")
app.configure(background='black')
app.resizable(False, False)

img1 = PhotoImage(file="new.jpg")

img0 = Label(app, image=img1, bg='black', )
img0.place(x=190, y=5)


def add_word():
    app.destroy()
    from dict import window
    window()


def clear():
    ent.delete(0, END)
    placeholder.delete(0.0, END)


def search():
    entry = ent.get().lower()
    csv_file = csv.reader(open("dictionary.csv", 'r'))
    empty_list = []
    for row in csv_file:
        empty_list.append(row[0])
        if entry + '\n' == row[0]:
            placeholder.delete(0.0, END)
            placeholder.insert(0.0, row)

    if str(entry)+'\n' not in empty_list:
        messagebox.showerror('Sorry', 'Word not found')


def photo_dict():
    app.destroy()
    from photodict import window
    window()


my_frame = Frame(app, width=45, height='10', background='white')
my_frame.place(x=0, y=310)
ver_scroll = Scrollbar(my_frame)
ver_scroll.pack(side=RIGHT, fill=Y)
hor_scroll = Scrollbar(my_frame, orient='horizontal')
hor_scroll.pack(side=BOTTOM, fill=X)
tit = Label(text="Word's Quest", fg='white', bg='black', font=('AR ESSENCE', 16))
tit.place(x=225, y=185)
ent = Entry(app, font=("", 18), width=12, borderwidth=8,  fg="black", bg="white")
ent.place(x=145, y=230)
sub = Button(app, text='Search', font=('Arial', 9), borderwidth=10, command=search,)
sub.place(x=335, y=230)
placeholder = Text(my_frame, font=('Arial', 16), wrap='none', yscrollcommand=ver_scroll.set,
                   xscrollcommand=hor_scroll.set, background='white', width=45, borderwidth=6, height='9', )
placeholder.pack()
sub = Button(app, text='Add word', command=add_word, font=('Arial', 9), borderwidth=10,  padx=2)
sub.place(x=226, y=555)
remove = Button(app, text='Clear', font=('Arial', 10), command=clear, borderwidth=10,  padx=2)
remove.place(x=110, y=555)
photo = Button(app, text='Open PhotoDictionary', bg='red', font=('Arial', 10), command=photo_dict,
               borderwidth=10,  padx=2)
photo.place(x=400, y=555)


ver_scroll.config(command=placeholder.yview)
hor_scroll.config(command=placeholder.xview)

app.mainloop()

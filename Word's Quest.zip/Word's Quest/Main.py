from tkinter import messagebox
from tkinter import *

main_window = Tk()
main_window.geometry("570x600+300+65")
main_window.resizable(False, False)
main_window.title("Word's Quest")
main_window.configure(bg="black")

img1 = PhotoImage(file="logo.jpg")
img2 = PhotoImage(file="i2.jpg")

img0 = Label(main_window, image=img1, bg='black', )
img0.place(x=100, y=10)
title = Label(main_window, text="Word's Quest", fg='white', bg='black', font=('AR ESSENCE', 16))
title.place(x=225, y=300)


def start_game():
    main_window.destroy()
    from eni import app
    app()


def info():
    messagebox.showinfo("Info", "Go on a quest for knowledge learning meanings to different words")


info_img = Button(main_window, image=img2, bg='black', border=0, justify='center', command=info, )
info_img.place(x=513, y=0)

start_btn = Button(main_window, text="Quest", width=18, borderwidth=9,
                   fg="black", bg="red", font=("AR ESSENCE", 18), command=start_game,)
start_btn.place(x=165, y=370)


main_window.mainloop()

from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image

window = Tk()
window.geometry('570x600+300+65')
window.title("Photo Dictionary")
window.configure(background='black')
window.resizable(False, False)

close = Button(window, text='X', command=quit, )
close.place(x=0, y=0)

ent = Entry(window, font=("", 18), width=15, borderwidth=8,  fg="black", bg="white")
ent.place(x=180, y=10)
ent.insert(0, '')

my_label = Label(window, bg='black')
my_label.place(x=0, y=100)


def search():
    link = r"images/" + ent.get()+'.JPG'
    try:
        my_image = ImageTk.PhotoImage(Image.open(link))
        my_label.configure(image=my_image)
        my_label.image = my_image

    except FileNotFoundError:
        messagebox.showerror("sorry", "Image not available")


button = Button(window, text='Find Image', borderwidth=6, command=search, bg='white', fg='black')
button.place(x=250, y=65)


window.mainloop()
